const jwt = require("jsonwebtoken");

const JWT_SECRET = process.env.JWT_SECRET;

const authMiddleware = (req, res, next) => {
  try {
    // Get Authorization header
    const authHeader = req.headers.authorization;

    // Check if header exists
    if (!authHeader) {
      return res.status(401).json({
        message: "Access denied. No token provided."
      });
    }

    // Expected format:
    // Authorization: Bearer <token>

    const parts = authHeader.split(" ");

    if (parts.length !== 2 || parts[0] !== "Bearer") {
      return res.status(401).json({
        message: "Invalid authorization format."
      });
    }

    const token = parts[1];

    // Verify JWT
    const decoded = jwt.verify(token, JWT_SECRET);

    // Store decoded user information in request
    req.user = decoded;

    // Continue to route
    next();

  } catch (error) {

    return res.status(401).json({
      message: "Invalid or expired token."
    });

  }
};

module.exports = authMiddleware;