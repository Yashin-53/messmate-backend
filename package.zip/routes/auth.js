const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const User = require("../models/User");

const router = express.Router();

const JWT_SECRET = process.env.JWT_SECRET;


// ========================================
// POST /auth/register
// Register a new user
// ========================================

router.post("/register", async (req, res) => {
  try {
    const { username, password } = req.body;

    // Validate required fields
    if (!username || !password) {
      return res.status(400).json({
        message: "Username and password are required."
      });
    }

    // Password length validation
    if (password.length < 6) {
      return res.status(400).json({
        message: "Password must be at least 6 characters long."
      });
    }

    // Check whether user already exists
    const existingUser = await User.findOne({
      username
    });

    if (existingUser) {
      return res.status(409).json({
        message: "User already exists."
      });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create user
    const newUser = new User({
      username,
      password: hashedPassword
    });

    await newUser.save();

    // Never return password
    return res.status(201).json({
      message: "User registered successfully",
      userId: newUser._id,
      username: newUser.username
    });

  } catch (error) {
    console.error("Registration error:", error);

    return res.status(500).json({
      message: "Registration failed due to server error."
    });
  }
});


// ========================================
// POST /auth/login
// Login existing user
// ========================================

router.post("/login", async (req, res) => {
  try {
    const { username, password } = req.body;

    // Validate fields
    if (!username || !password) {
      return res.status(400).json({
        message: "Username and password are required."
      });
    }

    // Find user
    const user = await User.findOne({
      username
    });

    if (!user) {
      return res.status(401).json({
        message: "Invalid credentials."
      });
    }

    // Compare entered password with hashed password
    const isMatch = await bcrypt.compare(
      password,
      user.password
    );

    if (!isMatch) {
      return res.status(401).json({
        message: "Invalid credentials."
      });
    }

    // Generate JWT
    const token = jwt.sign(
      {
        userId: user._id,
        username: user.username
      },
      JWT_SECRET,
      {
        expiresIn: "1d"
      }
    );

    return res.status(200).json({
      message: "Login successful",
      token
    });

  } catch (error) {
    console.error("Login error:", error);

    return res.status(500).json({
      message: "Login failed due to server error."
    });
  }
});


module.exports = router;